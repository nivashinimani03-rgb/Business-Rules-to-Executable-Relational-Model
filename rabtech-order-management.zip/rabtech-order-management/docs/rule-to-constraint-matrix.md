# Rule → Constraint Matrix

| # | Business rule                                                        | Mechanism                          | Where                                              | Boundary type      |
|---|-----------------------------------------------------------------------|-------------------------------------|-----------------------------------------------------|---------------------|
| 1 | Every order must reference an existing customer                       | Foreign key                         | `orders.customer_id REFERENCES customers(customer_id)` | Declarative constraint |
| 2 | `order_status` restricted to `PLACED` / `PAID` / `CANCELLED`          | CHECK constraint                    | `orders.order_status CHECK (...)`                   | Declarative constraint |
| 3 | `amount_inr` must be ≥ 0                                              | CHECK constraint                    | `orders.amount_inr CHECK (amount_inr >= 0)`         | Declarative constraint |
| 4 | Order date can't precede the customer's join date                     | BEFORE INSERT/UPDATE trigger        | `trg_order_not_before_join_date` (migration 002)    | Procedural / transaction boundary |
| 5 | Customer can't be deleted while orders exist                          | `ON DELETE RESTRICT` on the FK      | `orders.customer_id ... ON DELETE RESTRICT`         | Declarative constraint |

## Why rule 4 needed a trigger, not a CHECK

Rules 2 and 3 are single-row, single-table conditions — a plain `CHECK`
on the `orders` table is sufficient. Rule 4 depends on a value in
`customers`, and PostgreSQL `CHECK` constraints cannot reference another
table. The two mechanically sound options were:

- a `BEFORE INSERT OR UPDATE` trigger on `orders` (chosen — runs inside
  the same transaction as the write, so it either commits with the row
  or aborts the whole statement), or
- a deferred `EXCLUDE`/application-layer check (rejected — pushes an
  enforceable invariant out of the database and into every caller).

## Why rule 5 uses `RESTRICT` instead of `CASCADE`

`ON DELETE CASCADE` would silently delete a customer's order history the
moment the customer row is removed — that destroys financial records.
`RESTRICT` forces the delete to fail loudly instead, which matches the
retention need in the domain brief.
