# Conceptual ER Diagram

Renders natively in GitHub's Markdown preview (Mermaid).

```mermaid
erDiagram
    CUSTOMERS ||--o{ ORDERS : "places"

    CUSTOMERS {
        int customer_id PK
        varchar customer_name
        varchar city
        date joined_on
    }

    ORDERS {
        int order_id PK
        int customer_id FK
        date ordered_on
        varchar order_status "PLACED | PAID | CANCELLED"
        numeric amount_inr "must be >= 0"
    }
```

**Cardinality:** one `CUSTOMERS` row relates to zero-or-many `ORDERS`
rows (`||--o{`); every `ORDERS` row requires exactly one `CUSTOMERS` row.

**Rule call-outs not visible in the diagram shape alone** (see
[`rule-to-constraint-matrix.md`](rule-to-constraint-matrix.md) for the
full mapping):
- `orders.customer_id` → `ON DELETE RESTRICT` (rule 5)
- `orders.ordered_on` ≥ owning customer's `joined_on`, enforced by
  trigger (rule 4)
