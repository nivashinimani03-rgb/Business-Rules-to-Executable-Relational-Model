# Domain Brief — Order Management

One-day scope: convert a narrative order-management brief into enforceable
relational invariants for two entities, `customers` and `orders`.

## Entities

| Entity    | Description                                              |
|-----------|-----------------------------------------------------------|
| Customer  | A person who has registered on the platform.               |
| Order     | A single purchase placed by exactly one customer.          |

## States

`orders.order_status` is a closed lifecycle with three states:

```
PLACED ──► PAID
   │
   └────► CANCELLED
```

- **PLACED** — order created, payment not yet confirmed.
- **PAID** — payment confirmed.
- **CANCELLED** — order withdrawn before or instead of payment.

No other status value is valid; the lifecycle is closed, not extensible
at the row level.

## Cardinalities

- One `customer` → many `orders` (1 : N).
- Every `order` → exactly one `customer` (mandatory, non-nullable FK).
- A `customer` may exist with zero orders (registration alone doesn't
  require a purchase).

## Retention needs

- **Customers are never hard-deleted while they have orders.** Orders are
  financial records; deleting the owning customer would orphan them.
  Enforced with `ON DELETE RESTRICT` rather than `CASCADE`.
- **Cancelled orders are kept, not deleted**, for audit and reporting —
  the schema has no `DELETE` path for orders in this task's scope, only
  status transition to `CANCELLED`.

## Five non-negotiable business rules

1. **Every order must reference an existing customer.**
   No orphan orders — referential integrity is mandatory, not advisory.
2. **`order_status` must be one of `PLACED`, `PAID`, `CANCELLED`.**
   The lifecycle is closed; no free-text status values.
3. **`amount_inr` must never be negative.**
   Zero is allowed (e.g. fully-discounted orders); negative is not.
4. **An order's `ordered_on` date can never precede the owning
   customer's `joined_on` date.**
   A customer can't order before they existed as a customer — this is a
   cross-table temporal rule, not expressible as a single-column CHECK.
5. **A customer with any orders cannot be deleted.**
   Order history must survive independently of customer lifecycle
   decisions (retention requirement above).

See `docs/rule-to-constraint-matrix.md` for how each rule maps to a
concrete database mechanism, and `tests/negative_tests.sql` for proof
that each rule is actually enforced, not just documented.
