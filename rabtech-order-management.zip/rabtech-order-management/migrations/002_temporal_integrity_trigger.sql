-- 002_temporal_integrity_trigger.sql
-- Enforces Rule 4: an order can never be dated before the customer's
-- join date. This spans two tables, so it can't be expressed as a plain
-- column CHECK constraint (Postgres CHECK constraints can't subquery
-- another table) -- a BEFORE INSERT/UPDATE trigger is the correct
-- enforcement point instead.

BEGIN;

CREATE OR REPLACE FUNCTION enforce_order_not_before_join_date()
RETURNS TRIGGER AS $$
DECLARE
  v_joined_on DATE;
BEGIN
  SELECT joined_on INTO v_joined_on
  FROM customers
  WHERE customer_id = NEW.customer_id;

  IF NEW.ordered_on < v_joined_on THEN
    RAISE EXCEPTION
      'order_id % : ordered_on (%) cannot precede customer_id % joined_on (%)',
      NEW.order_id, NEW.ordered_on, NEW.customer_id, v_joined_on;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_order_not_before_join_date ON orders;

CREATE TRIGGER trg_order_not_before_join_date
  BEFORE INSERT OR UPDATE OF ordered_on, customer_id ON orders
  FOR EACH ROW
  EXECUTE FUNCTION enforce_order_not_before_join_date();

COMMIT;
