-- 001_init_schema.sql
-- RabTech Task 02: Business Rules to Executable Relational Model
-- Base schema for the order-management domain. Written to be repeatable:
-- DROP + CREATE guarded by IF EXISTS / IF NOT EXISTS so this file can be
-- re-run against a fresh or partially-built database without error.

BEGIN;

CREATE TABLE IF NOT EXISTS customers (
  customer_id   INTEGER PRIMARY KEY,
  customer_name VARCHAR(100) NOT NULL,
  city          VARCHAR(80)  NOT NULL,
  joined_on     DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  order_id      INTEGER PRIMARY KEY,
  customer_id   INTEGER NOT NULL
                REFERENCES customers(customer_id)
                ON DELETE RESTRICT,                         -- Rule 5
  ordered_on    DATE NOT NULL,
  order_status  VARCHAR(20) NOT NULL
                CHECK (order_status IN ('PLACED', 'PAID', 'CANCELLED')), -- Rule 2
  amount_inr    NUMERIC(10,2) NOT NULL
                CHECK (amount_inr >= 0)                      -- Rule 3
);

COMMIT;
