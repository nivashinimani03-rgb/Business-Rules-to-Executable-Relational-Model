# RabTech Task 02 — Business Rules to Executable Relational Model

Converts the order-management domain brief into an enforceable
PostgreSQL schema: five non-negotiable business rules, each mapped to a
concrete constraint or transaction boundary, with negative tests proving
every rule is actually enforced rather than just documented.

## Structure

```
docs/
  domain-brief.md              entities, states, cardinalities, retention, the 5 rules
  rule-to-constraint-matrix.md rule -> constraint mapping, with rationale
  er-diagram.md                conceptual ER diagram (Mermaid)
migrations/
  001_init_schema.sql          tables + declarative constraints (FK, CHECK, RESTRICT)
  002_temporal_integrity_trigger.sql   cross-table rule enforced via trigger
fixtures/
  commerce-seed-data.sql       original RabTech starter file, unmodified
  003_seed_fixtures.sql        idempotent seed data (ON CONFLICT DO NOTHING)
tests/
  negative_tests.sql           one block per rule; every block is expected to ERROR
```

## Running it locally (PostgreSQL)

```bash
createdb rabtech_order_management
psql -d rabtech_order_management -f migrations/001_init_schema.sql
psql -d rabtech_order_management -f migrations/002_temporal_integrity_trigger.sql
psql -d rabtech_order_management -f fixtures/003_seed_fixtures.sql

# Proof: every block below should print ERROR, then ROLLBACK
psql -d rabtech_order_management -f tests/negative_tests.sql
```

All three migration/fixture files are repeatable — re-running them
against the same database does not error (`IF NOT EXISTS`,
`CREATE OR REPLACE`, `ON CONFLICT DO NOTHING`).

## The five rules at a glance

| # | Rule | Enforced by |
|---|------|-------------|
| 1 | Every order references an existing customer | Foreign key |
| 2 | `order_status` ∈ {PLACED, PAID, CANCELLED} | CHECK |
| 3 | `amount_inr` ≥ 0 | CHECK |
| 4 | `ordered_on` can't precede the customer's `joined_on` | Trigger |
| 5 | A customer with orders can't be deleted | `ON DELETE RESTRICT` |

Full rationale for each mapping is in
[`docs/rule-to-constraint-matrix.md`](docs/rule-to-constraint-matrix.md).

## Verification

`tests/negative_tests.sql` was run against a live PostgreSQL 16 instance
during development: all five rule-violation blocks raised the expected
error, and the accompanying sanity check (deleting a customer with zero
orders) succeeded, confirming rule 5 isn't overly broad.
