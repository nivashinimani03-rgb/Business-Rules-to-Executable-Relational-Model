-- negative_tests.sql
-- Proof that each business rule is actually enforced by the schema, not
-- just documented. Each block is wrapped in its own transaction and
-- ROLLBACK'd so running this file never mutates the seeded data. Run
-- after 001_init_schema.sql, 002_temporal_integrity_trigger.sql and
-- fixtures/003_seed_fixtures.sql have been applied.
--
-- Expected result for every block below: an ERROR is raised. If any
-- block instead reports SUCCESS, that rule is not actually enforced.

-- ---------------------------------------------------------------------
-- Rule 1: every order must reference an existing customer (FK)
-- ---------------------------------------------------------------------
BEGIN;
  INSERT INTO orders (order_id, customer_id, ordered_on, order_status, amount_inr)
  VALUES (901, 999, '2026-05-01', 'PLACED', 500.00);
  -- expected: ERROR - violates foreign key constraint on customer_id
ROLLBACK;

-- ---------------------------------------------------------------------
-- Rule 2: order_status limited to PLACED / PAID / CANCELLED
-- ---------------------------------------------------------------------
BEGIN;
  INSERT INTO orders (order_id, customer_id, ordered_on, order_status, amount_inr)
  VALUES (902, 1, '2026-05-01', 'REFUNDED', 500.00);
  -- expected: ERROR - violates check constraint on order_status
ROLLBACK;

-- ---------------------------------------------------------------------
-- Rule 3: amount_inr must be >= 0
-- ---------------------------------------------------------------------
BEGIN;
  INSERT INTO orders (order_id, customer_id, ordered_on, order_status, amount_inr)
  VALUES (903, 1, '2026-05-01', 'PLACED', -100.00);
  -- expected: ERROR - violates check constraint on amount_inr
ROLLBACK;

-- ---------------------------------------------------------------------
-- Rule 4: ordered_on cannot precede the customer's joined_on
-- Customer 3 (Kabir Shah) joined 2026-02-02; backdate the order to
-- before that.
-- ---------------------------------------------------------------------
BEGIN;
  INSERT INTO orders (order_id, customer_id, ordered_on, order_status, amount_inr)
  VALUES (904, 3, '2026-01-15', 'PLACED', 500.00);
  -- expected: ERROR raised by trg_order_not_before_join_date
ROLLBACK;

-- ---------------------------------------------------------------------
-- Rule 5: a customer with existing orders cannot be deleted
-- Customer 1 (Aarav Mehta) owns orders 101 and 102 in the seed data.
-- ---------------------------------------------------------------------
BEGIN;
  DELETE FROM customers WHERE customer_id = 1;
  -- expected: ERROR - violates foreign key constraint (ON DELETE RESTRICT)
ROLLBACK;

-- ---------------------------------------------------------------------
-- Sanity check: a customer with NO orders can still be deleted.
-- This should stay a no-op re: rule 5 and succeed on its own -- proves
-- the RESTRICT is scoped to customers who actually have orders, not a
-- blanket "customers can never be deleted".
-- ---------------------------------------------------------------------
BEGIN;
  INSERT INTO customers (customer_id, customer_name, city, joined_on)
  VALUES (905, 'Test Only - No Orders', 'Chennai', '2026-05-01');
  DELETE FROM customers WHERE customer_id = 905;
  -- expected: SUCCESS (no error) - confirms rule 5 is not overly broad
ROLLBACK;
